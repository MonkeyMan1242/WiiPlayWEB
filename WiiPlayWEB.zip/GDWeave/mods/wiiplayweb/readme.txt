Thanks for playing with WiiPlayWEB!

Adds the Wii Play fish to WEBFISHING! All fish are found in lakes and rivers.

Version: 1.0.0
Authors: MonkeyMan1242
https://github.com/MonkeyMan1242/WiiPlayWEB

This mod was made with Hatchery 1.3.2
https://github.com/coolbot100s/Hatchery